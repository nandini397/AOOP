public interface BookActions {
    boolean isAvailable();
    void setAvailable(boolean isAvailable);
}
