public interface BorrowingRule {
    boolean canBorrow(Book book);
}
