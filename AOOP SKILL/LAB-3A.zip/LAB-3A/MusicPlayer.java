interface MusicPlayer {
    void play();
}
