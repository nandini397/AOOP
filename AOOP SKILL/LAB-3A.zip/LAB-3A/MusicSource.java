interface MusicSource {
    void play();
}