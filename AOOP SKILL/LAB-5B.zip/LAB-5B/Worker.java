public interface Worker {
    void work();
}
