public interface Eater {
    void eat();
}
