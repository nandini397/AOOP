class OnlineStreamPlayer {
    public void playStream(String url) {
        System.out.println("Streaming from URL: " + url);
    }
}