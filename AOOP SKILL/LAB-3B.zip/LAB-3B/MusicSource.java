
public interface MusicSource {

}
