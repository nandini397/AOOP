class RadioStationPlayer {
    public void playRadioStation(String station) {
        System.out.println("Tuning into radio station: " + station);
    }
}