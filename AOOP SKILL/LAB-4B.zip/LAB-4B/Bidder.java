public interface Bidder {
    void update(AuctionEvent event, String message);
}